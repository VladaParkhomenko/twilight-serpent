import pygame
from random import randrange

# Configuration for window and grid
WINDOW_RESOLUTION = 800  # Game window size in pixels (800x800)
CELL_SIZE = 50  # Size of each grid cell (snake step)

# Pygame initialization
pygame.init()
window_surface = pygame.display.set_mode([WINDOW_RESOLUTION, WINDOW_RESOLUTION])
clock = pygame.time.Clock()

# Fonts for score and game over screen
font_score_display = pygame.font.SysFont('Arial', 26, bold=True)
font_game_over = pygame.font.SysFont('Arial', 66, bold=True)

# Load background image
background_image = pygame.image.load('8.png').convert()


#  Quit game when window is closed
def handle_exit_event():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit()


# Draw snake and apple on the screen
def render_game_objects(snake_segments, apple_position):
    for segment_x, segment_y in snake_segments:
        pygame.draw.rect(window_surface, pygame.Color('springgreen'),
                         (segment_x, segment_y, CELL_SIZE - 1, CELL_SIZE - 1))
    pygame.draw.rect(window_surface, pygame.Color(255, 0, 80), (*apple_position, CELL_SIZE, CELL_SIZE))


# Show current score in top-left corner
def render_score(score):
    score_text = font_score_display.render(f'SCORE: {score}', True, pygame.Color(255, 204, 170))
    window_surface.blit(score_text, (5, 5))


# Display the game over screen
def render_game_over_screen():
    game_over_text = font_game_over.render('GAME OVER', True, pygame.Color(255, 204, 170))
    restart_text = font_score_display.render('Press SPACE to restart', True, pygame.Color('white'))
    window_surface.blit(game_over_text, (WINDOW_RESOLUTION // 2 - 200, WINDOW_RESOLUTION // 3))
    window_surface.blit(restart_text, (WINDOW_RESOLUTION // 2 - 160, WINDOW_RESOLUTION // 2))
    pygame.display.flip()


# Process input and control snake movement
def handle_snake_movement_input(movement_directions, current_direction_x, current_direction_y):
    keys = pygame.key.get_pressed()
    if (keys[pygame.K_w] or keys[pygame.K_UP]) and movement_directions['UP']:
        return 0, -1, {'UP': True, 'DOWN': False, 'LEFT': True, 'RIGHT': True}
    elif (keys[pygame.K_s] or keys[pygame.K_DOWN]) and movement_directions['DOWN']:
        return 0, 1, {'UP': False, 'DOWN': True, 'LEFT': True, 'RIGHT': True}
    elif (keys[pygame.K_a] or keys[pygame.K_LEFT]) and movement_directions['LEFT']:
        return -1, 0, {'UP': True, 'DOWN': True, 'LEFT': True, 'RIGHT': False}
    elif (keys[pygame.K_d] or keys[pygame.K_RIGHT]) and movement_directions['RIGHT']:
        return 1, 0, {'UP': True, 'DOWN': True, 'LEFT': False, 'RIGHT': True}
    return current_direction_x, current_direction_y, movement_directions


# Main game loop (one full snake session)
def run_snake_game():
    # Initial snake and apple positions
    snake_head_x = randrange(CELL_SIZE, WINDOW_RESOLUTION - CELL_SIZE, CELL_SIZE)
    snake_head_y = randrange(CELL_SIZE, WINDOW_RESOLUTION - CELL_SIZE, CELL_SIZE)
    apple_position = randrange(CELL_SIZE, WINDOW_RESOLUTION - CELL_SIZE, CELL_SIZE), randrange(CELL_SIZE,
                                                                                               WINDOW_RESOLUTION - CELL_SIZE,
                                                                                               CELL_SIZE)

    snake_length = 1
    snake_segments = [(snake_head_x, snake_head_y)]

    direction_x, direction_y = 0, 0
    game_speed = 60
    score = 0
    movement_tick_counter, snake_movement_delay = 0, 10

    # Prevent snake from reversing
    allowed_directions = {'UP': True, 'DOWN': True, 'LEFT': True, 'RIGHT': True}

    while True:
        # Draw background, snake and apple
        window_surface.blit(background_image, (0, 0))
        render_game_objects(snake_segments, apple_position)
        render_score(score)

        # Snake movement step timing
        movement_tick_counter += 1
        if not movement_tick_counter % snake_movement_delay:
            snake_head_x += direction_x * CELL_SIZE
            snake_head_y += direction_y * CELL_SIZE
            snake_segments.append((snake_head_x, snake_head_y))
            snake_segments = snake_segments[-snake_length:]

        # Check if apple is eaten
        if snake_segments[-1] == apple_position:
            apple_position = randrange(CELL_SIZE, WINDOW_RESOLUTION - CELL_SIZE, CELL_SIZE), randrange(CELL_SIZE,
                                                                                                       WINDOW_RESOLUTION - CELL_SIZE,
                                                                                                       CELL_SIZE)
            snake_length += 1
            score += 1
            snake_movement_delay = max(snake_movement_delay - 1, 4)

        # Check for collision with wall or itself
        if (
                snake_head_x < 0 or snake_head_x > WINDOW_RESOLUTION - CELL_SIZE or
                snake_head_y < 0 or snake_head_y > WINDOW_RESOLUTION - CELL_SIZE or
                len(snake_segments) != len(set(snake_segments))
        ):
            break

        # Refresh display and control frame rate
        pygame.display.flip()
        clock.tick(game_speed)
        handle_exit_event()

        # Handle input
        direction_x, direction_y, allowed_directions = handle_snake_movement_input(
            allowed_directions, direction_x, direction_y
        )


# Overall game loop (with restart support)
while True:
    run_snake_game()
    render_game_over_screen()

    wait_for_restart = True
    while wait_for_restart:
        handle_exit_event()
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                wait_for_restart = False
